
let dish = [{
    name: "Lakseroulade m. spinat",
    image: "🥧",
    price: 85
  },
  {
    name: "Italiensk Bruchetta",
    image: "🍲",
    price: 110
  },
  {
    name: "Nachos m. ost og kylling",
    image: "🍲",
    price: 120
  },
            {
    name: "Hjemmebagt brød m. tilbehør",
    image: "🍲",
    price: 75
  },
            {
    name: "Cæsar Salat m. hjemmerørt dressing",
    image: "🍲",
    price: 112
  }
]

let amount = 0
sum.innerHTML = amount

/* display the menu */
for (let i = 0; i < dish.length; i++) {

  theMenu.innerHTML += `
    <div class="aDish">
      <h3>  ${dish[i].name} </h3>
      <p> ${dish[i].image}  </p>
      <p> Price: ${dish[i].price} kr. </p>
      <button onclick="anOrder(
        '${dish[i].name}',
        '${dish[i].price}'
        )"> BESTIL ${dish[i].name}</button>
    <div>
  `
}

// add order til orderlist
function anOrder(order, price, i) {
  // create list
  ordersList.innerHTML += '<li class="orderItem">' + order
  +  ' price: ' + price + ' kr.'+
  ' <button onclick="this.parentNode.remove();amount-='+ parseInt(price) +';sum.innerHTML=amount">Fjern</button> </li>'
  // update amount
  amount += parseInt( price ) // string to number
  sum.innerHTML = amount + ' kr.';
  sum.innerHTML += `
    <form action="thanx.html">
    <button> BETAL</button>
    </form>
  `

  // sessionStorage - save data in the session
  sessionStorage.setItem("yourOrders", orders.innerHTML)
  console.log(sessionStorage.getItem("yourOrders"))
}

// save orders session